/************************
 * Javascript-tiedosto tehtävään 8
 ************************/

/****

$(document).ready(function(){
    // Tähän sivun lataamisen jälkeen suoritettava koodi
});

*****/

$(document).ready(function(){
    $('#haitari1 h2.haitariotsikko').on('click', function(event){
        event.stopPropagation();
        $(this).toggleClass('auki');
    });
    $('#haitari2 h2.haitariotsikko').on('click', function(event){
        event.stopPropagation();
        var otsikko = $(this);
        var auki = otsikko.hasClass('auki');
        var sisalto = otsikko.next('.haitarisisalto');
        if (!auki) {
            otsikko.addClass('auki');
            sisalto.slideDown();
        } else {
            otsikko.removeClass('auki');
            sisalto.slideUp();
        }
    });
    $('#haitari3 h2.haitariotsikko').on('click', function(event){
        event.stopPropagation();
        var otsikko = $(this);
        var auki = otsikko.hasClass('auki');
        var sisalto = otsikko.next('.haitarisisalto');
        var haitari = otsikko.closest('.haitari');
        haitari.children('.haitariotsikko').removeClass('auki');
        haitari.children('.haitarisisalto').slideUp();
        if (!auki) {
            otsikko.addClass('auki');
            sisalto.slideDown();
        };
    });
});

