/************************
 * Javascript-tiedosto tehtävään 8
 ************************/

/****

$(document).ready(function(){
    // Tähän sivun lataamisen jälkeen suoritettava koodi
});

*****/

